import CustomPalette from './CustomPalette';

export default {
  __init__: ['customPalette'],
  customPalette: ['type', CustomPalette]
};
