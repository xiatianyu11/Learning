# bpmn-vue3

#### 介绍
基于 Bpmn.js、Vue 3.x 、Element-plus 和vite的流程编辑器（前端部分），参考[bpmn-process-designer](https://gitee.com/MiyueSC/bpmn-process-designer)，支持监听器，扩展属性，表单等配置，可自由扩展

[demo](http://bpmn.majh.top/)

本版本是在`bpmn-process-designer` vue2 基础上修改，稍微做了些改动，感谢 @MiyueFE

#### 1. 安装依赖

```shell
npm install
// or yarn install
```

#### 2. 运行

```shell
npm run dev
// or yarn run dev
```